document.getElementById('bookingForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const movie = document.getElementById('movie').value;
    const seats = document.getElementById('seats').value;
  
    const response = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, movie, seats })
    });
  
    const result = await response.json();
    document.getElementById('response').innerText = result.message;
  });
  