const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

// Load bookings
let bookings = [];
const bookingsFile = './bookings.json';

if (fs.existsSync(bookingsFile)) {
  bookings = JSON.parse(fs.readFileSync(bookingsFile));
}

// API to get all bookings
app.get('/api/bookings', (req, res) => {
  res.json(bookings);
});

// API to create a new booking
app.post('/api/bookings', (req, res) => {
  const booking = req.body;
  bookings.push(booking);
  fs.writeFileSync(bookingsFile, JSON.stringify(bookings, null, 2));
  res.status(201).json({ message: 'Booking successful!' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
